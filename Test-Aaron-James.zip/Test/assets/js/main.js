

$(function () {
    $('.slider').slick({
        slidesToShow: 1,
        arrows: true, 
        prevArrow: $('.slide-prev'),
        nextArrow: $('.slide-next'),  
    });

    $('.slider-nav').slick({
        slidesToShow: 6,
        asNavFor: '.slider', 
        focusOnSelect: true
    });
    
});

