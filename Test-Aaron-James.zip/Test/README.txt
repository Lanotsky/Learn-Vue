Hello.

Sorry. There is no mobile mode for this page
I was trying to meet my work deadlines while making 
this.

I've never used Vue.js before but I've grown to like it now.

Thank you

--Aaron Jame Lanot