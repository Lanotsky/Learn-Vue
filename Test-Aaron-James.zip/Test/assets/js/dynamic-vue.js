//  DISCAIMER
// I'VE USED REACT.JS BEFORE BUT THIS IS MY FIRST TIME USING VUE.JS

Vue.component('recent-item', {
    props: ['recent'],
    template: '<div class="item">' + '<div class="recent-img">' + '<img :src="recent.img" alt="">  </div>' + '<div class="recent-desc">' + '<p>{{recent.heading}}</p>' + '<span>{{recent.date}}</span>' + '</div> </div>'
                                        
})

var recentList = [
    { id: 0, img: "./assets/img/recent-img.png", heading: "CHARACTER DESIGN", date: 'JUNE 15 2012' },
    { id: 2, img: "./assets/img/thumbnail-2.png", heading: "BROCHURE DESIGN", date: 'JUNE 15 2012' },
    { id: 3, img: "./assets/img/social-media.png", heading: "SOCIAL MEDIA BUTTONS", date: 'JUNE 15 2012' },
    { id: 4, img: "./assets/img/thumbnail-6.png", heading: "10 AMAZING WEBSITES", date: 'JUNE 15 2012' }
]


var element = new Vue({
    el: '#dynamic-vue',
    data: {
        recentList,
    }
})
